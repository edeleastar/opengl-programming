#pragma once

#include "libopengl.h"

#include <boost/foreach.hpp>
#define foreach BOOST_FOREACH

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <sstream>

#include <vector>
#include <map>

#include <boost/ptr_container/ptr_map.hpp>
