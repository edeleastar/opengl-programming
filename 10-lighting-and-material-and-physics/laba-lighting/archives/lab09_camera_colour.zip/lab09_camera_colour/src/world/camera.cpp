#include "libs.h"
#include "camera.h"
#include <math.h>
#include <stdlib.h>

#define GL_PI 3.1415

using namespace std;

Camera::Camera()
: position(0,0,0), xrot(0), yrot(0), cRadius(5)
{
}

void Camera::render()
{
  glTranslatef(0.0f, 0.0f, -cRadius);
  Vector3::UnitX.rotate(xrot);
  Vector3::UnitY.rotate(yrot);
  glTranslated(-position.X, 0.0f, -position.Z);
}

void Camera::specialKeyboard(int key, int x, int y)
{
  float xrotrad, yrotrad;
  switch (key)
  {
    case 101: yrotrad = (yrot / 180 * GL_PI);
              xrotrad = (xrot / 180 * GL_PI);
              position.X += float(sin(yrotrad));
              position.Z -= float(cos(yrotrad));
              position.Y -= float(sin(xrotrad));
              break;

    case 103: yrotrad = (yrot / 180 * GL_PI);
              xrotrad = (xrot / 180 * GL_PI);
              position.X -= float(sin(yrotrad));
              position.Z += float(cos(yrotrad));
              position.Y += float(sin(xrotrad));
              break;

    case 102: yrotrad = (yrot / 180 * GL_PI);
              position.X += float(cos(yrotrad)) * 0.2;
              position.Z += float(sin(yrotrad)) * 0.2;
              break;

    case 100: yrotrad = (yrot / 180 * GL_PI);
              position.X -= float(cos(yrotrad)) * 0.2;
              position.Z -= float(sin(yrotrad)) * 0.2;
              break;
  }
}

void Camera::mouseMovement(int x, int y)
{
  int diffx = x - lastx;
  int diffy = y - lasty;
  lastx = x;
  lasty = y;
  xrot += (float) diffy;
  yrot += (float) diffx;
}
