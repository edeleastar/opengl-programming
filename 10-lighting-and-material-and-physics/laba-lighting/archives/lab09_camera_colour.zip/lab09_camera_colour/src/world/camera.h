#pragma once
#include "vector3.h"

struct Camera
{
  Camera();

  void specialKeyboard (int key, int x, int y);
  void mouseMovement(int x, int y);
  void render();

  Vector3 position;
  float xrot, yrot, cRadius, lastx, lasty;
};
