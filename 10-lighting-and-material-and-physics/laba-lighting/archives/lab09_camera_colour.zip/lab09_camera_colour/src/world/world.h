#pragma once
#include "libs.h"
#include "renderable.h"
#include "projectors.h"
#include "geometry.h"
#include "camera.h"
#include "scene.h"

#define theWorld World::GetInstance()

struct World
{
  void initialize(std::string name, int width, int height);

  void keyPress(unsigned char ch);
  void specialKeyPress(int key, int x, int y);
  void mouseMovement(int x, int y);

  void start();
  void render();
  void tickAndRender();

  static World& GetInstance();
  static World  *s_World;

  Scene         *scene;
  Projectors     projectors;
  Camera         camera;
};

