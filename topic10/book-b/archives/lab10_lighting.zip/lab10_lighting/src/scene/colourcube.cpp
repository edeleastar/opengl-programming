#include "libs.h"
#include "colourcube.h"
#include "Color.h"

/*
Color colours[] =
{
  Color::White,   Color::Yellow, Color::Red,     Color::Magenta,
  Color::Cyan,    Color::Green,  Color::Black,   Color::Blue,
  Color::Cyan,    Color::White,  Color::Magenta, Color::Blue,
  Color::Green,   Color::Yellow, Color::Red,    Color::Black,
  Color::White,   Color::Cyan,   Color::Green,  Color::Yellow,
  Color::Magenta, Color::Blue,   Color::Black,  Color::Red
};
*/

Color colours[][6] =
{
  { Color::White,   Color::Yellow, Color::Red,     Color::Magenta },
  { Color::Cyan,    Color::Green,  Color::Black,   Color::Blue    },
  { Color::Cyan,    Color::White,  Color::Magenta, Color::Blue    },
  { Color::Green,   Color::Yellow, Color::Red,     Color::Black   },
  { Color::White,   Color::Cyan,   Color::Green,   Color::Yellow  },
  { Color::Magenta, Color::Blue,   Color::Black,   Color::Red     }
};

Vector3 vertices[][6] =
{
  { Vector3(-1.0f, 1.0f, 1.0f), Vector3(-1.0f, -1.0f, 1.0f), Vector3( 1.0f, -1.0f, 1.0f), Vector3( 1.0f, 1.0f, 1.0f)  },
  { Vector3( 1.0f, 1.0f,-1.0f), Vector3( 1.0f, -1.0f,-1.0f), Vector3(-1.0f, -1.0f,-1.0f), Vector3(-1.0f, 1.0f, -1.0f) },
  { Vector3(-1.0f, 1.0f,-1.0f), Vector3(-1.0f,  1.0f, 1.0f), Vector3( 1.0f,  1.0f, 1.0f), Vector3( 1.0f, 1.0f, -1.0f) },
  { Vector3( 1.0f,-1.0f,-1.0f), Vector3( 1.0f, -1.0f, 1.0f), Vector3(-1.0f, -1.0f, 1.0f), Vector3(-1.0f,-1.0f, -1.0f) },
  { Vector3( 1.0f,-1.0f, 1.0f), Vector3( 1.0f, -1.0f,-1.0f), Vector3( 1.0f,  1.0f,-1.0f), Vector3( 1.0f, 1.0f,  1.0f) },
  { Vector3(-1.0f, 1.0f, 1.0f), Vector3(-1.0f, 1.0f, -1.0f), Vector3(-1.0f, -1.0f,-1.0f), Vector3(-1.0f, -1.0f, 1.0f) }
};

void drawFace(Color colours[], Vector3 vertices[])
{
  for (int i=0; i<4; i++)
  {
    colours[i].render();
    vertices[i].render();
  }
}

//ColourCube::ColourCube(Geometry* g) : Actor(g)
//{}

ColourCube::ColourCube()
{}

void ColourCube::render()
{
  glPolygonMode(GL_FRONT,GL_FILL);
  glPolygonMode(GL_BACK,GL_FILL);
  glBegin( GL_QUADS);
  for (int i=0; i<6; i++)
  {
    drawFace(colours[i], vertices[i]);
  }
  glEnd();
  glPolygonMode(GL_FRONT,GL_LINE);
  glPolygonMode(GL_BACK,GL_LINE);
  /*
  glShadeModel(GL_SMOOTH);
  glPolygonMode(GL_FRONT,GL_FILL);
  glPolygonMode(GL_BACK,GL_FILL);


  int edge=0;
  foreach (Face &face, geometry->faces)
  {
    glBegin(GL_QUADS);

    foreach (int index, face.vertexIndices)
    {
      colours[edge].render();
      glVertex3f( geometry->vertexGroup->vertices[index-1].X,
                  geometry->vertexGroup->vertices[index-1].Y,
                  geometry->vertexGroup->vertices[index-1].Z );
      edge++;
    }
    glEnd();
  }
  glPolygonMode(GL_FRONT,GL_LINE);
  Color::White.render();*/
}
