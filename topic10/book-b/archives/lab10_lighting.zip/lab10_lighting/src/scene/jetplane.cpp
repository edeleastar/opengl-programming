#include "libs.h"
#include "jetplane.h"
#include "Color.h"
#include "jetplanegeometry.h"
#include "lights.h"

using namespace std;

void render (Vector3 vectors[][3], int size)
{
  for (int i=0; i<size; i++)
  {
    glBegin(GL_TRIANGLES);
      Vector3 normal = findNormal( vectors[i][0], vectors[i][1], vectors[i][2]);
      glNormal3f(normal.X, normal.Y, normal.Z);
      vectors[i][0].render();
      vectors[i][1].render();
      vectors[i][2].render();
    glEnd();
  }
}

JetPlane::JetPlane()
{}

void JetPlane::render()
{
  glShadeModel(GL_SMOOTH);
  glPolygonMode(GL_FRONT,GL_FILL);

  Color::Yellow.render();
  applyMaterial (brass);
  ::render(noseCone, 3);
  Color::Red.render();
  applyMaterial (plasticBlack);
  ::render(body, 3);
  Color::Green.render();
  applyMaterial (chrome);
  ::render(wings, 4);
  Color::Cyan.render();
  applyMaterial (bronze);
  ::render(tail, 7);

  Color::White.render();
  glPolygonMode(GL_FRONT,GL_LINE);
}
