#pragma once

#include "camera.h"

struct ThirdPersonCamera : public Camera
{
  ThirdPersonCamera()
  : cRadius(5)
  {}

  void specialKeyboard (int key, int x, int y);
  void mouseMovement(int x, int y);
  void render();

  float cRadius, lastx, lasty;
};
