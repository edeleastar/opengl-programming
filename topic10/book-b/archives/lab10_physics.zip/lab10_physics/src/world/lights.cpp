#include "libs.h"
#include "lights.h"


struct Material
{
  GLfloat ambient[4];
  GLfloat diffuse[4];
  GLfloat specular[4];
  GLfloat shiny;
};

float ambientLightFull[] = { 1.0f, 1.0f, 1.0f, 1.0f };
float ambientLightHalf[] = { 0.5f, 0.5f, 0.5f, 1.0f };
float ambientLightDefault[] = { 0.2f, 0.2f, 0.2f, 1.0f };

Material materials [] =
{
    { {0.8, 0.0, 0.0, 1.0}, // flatRed
      {0.8, 0.0, 0.0, 1.0},
      {0.8, 0.0, 0.0, 1.0}, 25.0 },

    { {0.8, 0.0, 0.0, 1.0}, //flatYellow
      {0.8, 0.0, 0.0, 1.0},
      {0.8, 0.0, 0.0, 1.0}, 25.0 },

    { {0.0, 0.0, 0.8, 1.0}, // flatblue
      {0.0, 0.0, 0.8, 1.0},
      {0.0, 0.0, 0.8, 1.0}, 25.0 },

    { {0.0, 0.8, 0.0, 1.0}, // flatgreen
      {0.0, 0.8, 0.0, 1.0},
      {0.0, 0.8, 0.0, 1.0}, 25.0 },

    { {0.5, 0.5, 0.5, 1.0}, // flatgrey
      {0.5, 0.5, 0.5, 1.0},
      {0.5, 0.5, 0.5, 1.0}, 25.0 },

    { {0.3, 0.0, 0.0, 1.0}, //plasticRed
      {0.6, 0.0, 0.0, 1.0},
      {0.8, 0.6, 0.6, 1.0}, 32.0 },

    { {1.0, 1.0, 1.0, 1.0}, //shinyWhite
      {1.0, 1.0, 1.01, 1.0},
      {1.0, 1.0, 1.0, 1.0}, 100.0 },

    { {0.329412, 0.223529, 0.027451, 1.0}, //brass
      {0.780392, 0.568627, 0.113725, 1.0},
      {0.9922157, 0.941176, 0.807843, 1.0}, 27.8974 },

    { {0.2125, 0.1275, 0.054, 1.0}, //bronze
      {0.714, 0.4284, 0.18144, 1.0},
      {0.303548, 0.271906, 0.106721, 1.0}, 25.6 },

    { {0.25, 0.25, 0.25, 1.0}, //chrome
      {0.4, 0.4, 0.4, 1.0},
      {0.774597, 0.774597, 0.774597, 1.0}, 76.8 },

    { {0.19125, 0.0735, 0.0225, 1.0}, //copper
      {0.7038, 0.27048, 0.0828, 1.0},
      {0.256777, 0.137622, 0.086014, 1.0},  12.8 },

    { {0.24725, 0.1995, 0.0745, 1.0},// gold
      {0.75164, 0.60648, 0.22658, 1.0},
      {0.628281, 0.555802, 0.366065, 1.0},  51.2 },

    { {0.10558, 0.058824, 0.113725, 1.0}, //pewter
      {0.427451, 0.470588, 0.541176, 1.0},
      {0.3333, 0.3333, 0.521569, 1.0}, 9.84615 },

    { {0.19225, 0.19225, 0.19225, 1.0}, //silver
      {0.50754, 0.50754, 0.50754, 1.0},
      {0.508273, 0.508273, 0.508273, 1.0}, 51.2 },

    { {0.23125, 0.23125, 0.23125, 1.0}, //polishSilver
      {0.2775, 0.2775, 0.2775, 1.0},
      {0.773911, 0.773911, 0.773911, 1.0}, 89.6 },

    { {0.0, 0.0, 0.0, 1.0}, //plasticBlack
      {0.01, 0.01, 0.01, 1.0},
      {0.50, 0.50, 0.50, 1.0},32.0 }
};


void applyMaterial(MaterialTypes material)
{
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT,   materials[material].ambient);
  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE,   materials[material].diffuse);
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR,  materials[material].specular);
  glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, materials[material].shiny);
}

void basicAmbient()
{
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLightFull);
}

void grayMaterial()
{
  float gray[] =  { 0.75f, 0.75f, 0.75f, 1.0f };
  glMaterialfv(GL_FRONT,  GL_AMBIENT_AND_DIFFUSE, gray);
}

void colourTracking()
{
  glEnable(GL_COLOR_MATERIAL);
  glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
}

void lightSource()
{
  float  ambientLightModerate[] = { 0.3f, 0.3f, 0.3f, 1.0f };
  float  diffuseLightModerate[] = { 0.7f, 0.7f, 0.7f, 1.0f };

  glLightfv(GL_LIGHT0,GL_AMBIENT,ambientLightModerate);
  glLightfv(GL_LIGHT0,GL_DIFFUSE,diffuseLightModerate);

  glEnable(GL_LIGHT0);
  glEnable(GL_NORMALIZE);
}

void positionLight()
{
  float lightPos[] = { -50.f, 50.0f, 0.0f, 1.0f };
  glLightfv(GL_LIGHT0,GL_POSITION,lightPos);
}
