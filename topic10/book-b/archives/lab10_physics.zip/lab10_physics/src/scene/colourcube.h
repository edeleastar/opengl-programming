#pragma once
#include "actor.h"

struct ColourCube: public Actor
{
  ColourCube();
  //ColourCube(Geometry* g);
  void render();
};
