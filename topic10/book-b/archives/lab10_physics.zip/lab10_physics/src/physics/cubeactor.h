#pragma once

#include "physicsactor.h"

struct CubeActor : public PhysicsActor
{
    CubeActor(Geometry *);
};
