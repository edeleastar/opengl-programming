#include "geometry.h"
using namespace std;

Geometry::Geometry()
{
}

Geometry::Geometry(string groupName, istream& is, VertexGroup*group)
: name(groupName), vertexGroup(group)
{
  string indicator;
  bool stillGroup=true;
  do
  {
    is >> indicator;
    if (indicator == "f")
    {
      faces.push_back(Face(is));
    }
    else if (indicator == "g")
    {
      stillGroup = false;
    }
    else
    {
      string buf;
      getline(is, buf);
    }
  } while (stillGroup && !is.eof());
  is.putback(indicator[0]);
}

void Geometry::extractVertices()
{
  int newIndex=0;
  foreach (Face &face, faces)
  {
    foreach (int index, face.vertexIndices)
    {
      Vector3 vertex(vertexGroup->vertices[index-1].X, vertexGroup->vertices[index-1].Y, vertexGroup->vertices[index-1].Z);
      localVertices.push_back(vertex);
      face.localVertexIndices.push_back(newIndex);
      newIndex++;
    }
  }
}

void Geometry::render()
{
  foreach (Face &face, faces)
  {
    //face.render(vertexGroup->vertices);
    face.renderLocal(localVertices);
  }
}
