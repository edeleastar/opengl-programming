#pragma once
#include "libs.h"
#include "vector3.h"
#include "face.h"
#include "vertexgroup.h"
#include "renderable.h"

struct Geometry : public Renderable
{
  std::string name;
  std::vector<Face> faces;
  std::vector<Vector3> localVertices;
  VertexGroup *vertexGroup;

  Geometry();
  Geometry(std::string name, std::istream&, VertexGroup*);
  void extractVertices();
  void render();
};

typedef std::map <std::string, Geometry>  GeometryMap;
