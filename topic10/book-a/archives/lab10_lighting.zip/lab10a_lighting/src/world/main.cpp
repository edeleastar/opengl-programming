#include "world.h"
#include "model.h"

using namespace std;

Model* loadModel(const char *name)
{
  Model * model = 0;
  ifstream inStream;
  inStream.open(name, ios::in);
  if (!inStream.fail())
  {
    model = new Model();
    model->load(inStream);
    model->extractVertices();
  }
  return model;
}

int main(int argc, char* argv[])
{
  theWorld.initialize("First World", 600,600);

  Model *model = loadModel("physicsmodel.obj");
  if (!model)
  {
    cerr << "Cannot find model file. Aborting ...\n";
    return 1;
  }

  Scene *scene = new Scene (model);
  theWorld.scene = scene;

  theWorld.start();
  return 0;
}
