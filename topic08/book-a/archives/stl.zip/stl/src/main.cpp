#include "util.h"

void vectest();
void listtest();
void dequetest();
void settest();
void maptest();
void stacktest();
void queuetest();
void priorityqueuetest();
void iteratortest();

void polytest1();
void polytest2();
void polytest3();
void polytest4();
void polytest5();
void polytest6();
void polytest7();
void polytest8();
void polytest9();

int main()
{
/*  vectest();
  listtest();
  dequetest();
  settest();
  maptest();
  stacktest();
  queuetest();
  priorityqueuetest();
  iteratortest();*/

	polytest9();
}
