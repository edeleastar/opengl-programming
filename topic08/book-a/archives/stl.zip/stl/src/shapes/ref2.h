#pragma once 

template < class T >
class Ref2
  {
  public:
    Ref2(const T &s)                           {KillData = true;  t = s.clone();}
    Ref2(T *s)                                 {KillData = false; t = s;}
    Ref2(const Ref2 < T > &r)                  {KillData = true;
                                                t = r.t?r.t->clone():NULL;}
    ~Ref2()                                    {if (t && KillData) delete t;}
    Ref2& operator= (const Ref2 < T > & r)     {if (t && KillData) delete t;
                                                KillData = true;
                                                t = r.t?r.t->clone():NULL;
                                                return *this; }
    T* operator->() const                      {return t;}
    int operator< (const Ref2 < T > & r) const {return t?r.t?(*t) < (*r.t):false:true;}
    operator T&()   const                      {return *t;}
    operator T*()   const                      {return t;}
    T& operator*()  const                      {return *t;}
  protected:
    T *t;
  private:
    bool KillData;
  };