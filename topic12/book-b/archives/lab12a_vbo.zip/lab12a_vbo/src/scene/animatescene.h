#pragma once
#include "libs.h"
#include "scene.h"
#include "animateactor.h"
#include "forcegeneratorregistry.h"

struct AnimateScene : public Scene
{
  AnimateScene();
  Actor* loadActor(GeometryMap::value_type &value);

  void tick(float secondsDelta);

  AnimateActorMap        animateActors;
  ForceGeneratorRegistry forceGeneratorRegistry;
};
