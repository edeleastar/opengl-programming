#include "scene.h"
#include "colourcube.h"
#include "jetplane.h"
#include "grid.h"

#include "vageometry.h"

using namespace std;

Scene:: Scene()
{
}

void Scene::loadActors(Model*model)
{
  string actorName;
  foreach (GeometryMap::value_type value, model->entities)
  {
    Actor* actor = loadActor(value);
    if (actor)
    {
      actorName = value.first;
      actors.insert(actorName, actor);
    }
  }
  //actorName = "grid";
 // actors.insert (actorName, new Grid());
 // actorName = "jet";
 // actors.insert (actorName, new JetPlane());
}

Actor* Scene::loadActor(GeometryMap::value_type &value)
{
  return new Actor(value.second);
}

void Scene::render()
{
  foreach (ActorMap::value_type value, actors)
  {
    value->second->render();
  }
}
