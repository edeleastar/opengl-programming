#pragma once
#include "elementgeometry.h"

struct VboGeometry : public ElementGeometry
{
  GLuint ids[2];

  VboGeometry();
  VboGeometry(std::string name, std::istream&, VertexGroup*);

  void render();
  void extractVertices();
};
