#pragma once
#include "libs.h"
#include "vector3.h"
#include "face.h"
#include "vertexgroup.h"
#include "renderable.h"

struct Geometry : public Renderable
{
  std::string name;
  std::vector<Face> faces;
  VertexGroup *vertexGroup;
  std::vector<Vector3> vertices;

  Geometry();
  Geometry(std::string name, std::istream&, VertexGroup*);

  virtual void render()=0;
  virtual void extractVertices()=0;
};

typedef boost::ptr_map <std::string, Geometry>  GeometryMap;

