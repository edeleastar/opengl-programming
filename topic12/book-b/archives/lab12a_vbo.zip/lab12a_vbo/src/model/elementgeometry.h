#pragma once
#include "geometry.h"

struct Elements
{
  std::vector<float> vertices;
  std::vector<GLushort>   indices;
};

struct ElementGeometry : public Geometry
{
  Elements elements;

  ElementGeometry();
  ElementGeometry(std::string name, std::istream&, VertexGroup*);

  void render();
  void extractVertices();
};
