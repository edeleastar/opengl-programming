#include "elementgeometry.h"
using namespace std;

ElementGeometry::ElementGeometry()
{
}

ElementGeometry::ElementGeometry(string groupName, istream& is, VertexGroup*group)
: Geometry (groupName, is, group)
{
}

void ElementGeometry::render()
{
  glEnableClientState(GL_VERTEX_ARRAY);

  glVertexPointer(3, GL_FLOAT, 0, &elements.vertices[0]);
  glDrawElements(GL_TRIANGLES, elements.indices.size(), GL_UNSIGNED_SHORT, &elements.indices[0]);

  glDisableClientState(GL_VERTEX_ARRAY);
}

void ElementGeometry::extractVertices()
{
  typedef map <GLushort,GLushort> IndexMap;
  IndexMap indexMap;
  int newIndex=0;
  foreach (Face &face, faces)
  {
    foreach (int index, face.vertexIndices)
    {
      Vector3 vertex(vertexGroup->vertices[index-1].X, vertexGroup->vertices[index-1].Y, vertexGroup->vertices[index-1].Z);
      if (indexMap.find(index) == indexMap.end())
      {
        indexMap[index] = newIndex;
        elements.vertices.push_back(vertex.X);
        elements.vertices.push_back(vertex.Y);
        elements.vertices.push_back(vertex.Z);
        elements.indices.push_back(newIndex);
        newIndex++;
      }
      else
      {
        elements.indices.push_back(indexMap[index]);
      }
    }
  }

  static int totalVertices = 0;
  totalVertices += elements.vertices.size();
  cout << "Vertices for " << name << ':' << elements.vertices.size() << endl;
  cout << "total vertices to date: " << totalVertices << endl;
}

