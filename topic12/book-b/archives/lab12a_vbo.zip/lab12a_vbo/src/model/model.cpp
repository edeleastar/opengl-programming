#include "model.h"
#include "geometry.h"
#include "vageometry.h"
#include "immediategeometry.h"
#include "elementgeometry.h"
#include "vbogeometry.h"

using namespace std;
using namespace boost;

Model::Model()
{
}

bool Model::load(istream& is)
{
  string indicator;
  is >> indicator;
  while (!is.eof())
  {
    if (indicator == "#")
    {
      string buf;
      getline(is, buf);
    }
    else if (indicator == "g")
    {
      string name;
      is >> name;
      if (name == "default")
      {
        defaultGroup.load(is);
      }
      else
      {
        Geometry *geometry = new VboGeometry(name, is, &defaultGroup);
        geometry->extractVertices();
        if (entities.find(geometry->name) == entities.end())
        {
          entities.insert(geometry->name, geometry);
        }
      }
    }
    is >> indicator;
  }
  return true;
}

void Model::render()
{
  foreach (GeometryMap::value_type value, entities)
  {
    value.second->render();
  }
}

