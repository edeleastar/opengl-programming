#pragma once
#include "geometry.h"

struct ImmediateGeometry : public Geometry
{
  ImmediateGeometry();
  ImmediateGeometry(std::string name, std::istream&, VertexGroup*);

  void render();
  void extractVertices();
};
