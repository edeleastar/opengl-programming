#include "VaGeometry.h"
using namespace std;

VaGeometry::VaGeometry()
{
}

VaGeometry::VaGeometry(string groupName, istream& is, VertexGroup*group)
: Geometry (groupName, is, group)
{
}

void VaGeometry::render()
{
  glEnableClientState(GL_VERTEX_ARRAY);

  glVertexPointer(3, GL_FLOAT, 0, &rawVertices[0]);
  glDrawArrays(GL_TRIANGLES, 0, rawVertices.size()/3);

  glDisableClientState(GL_VERTEX_ARRAY);
}

void VaGeometry::extractVertices()
{
  foreach (Face &face, faces)
  {
    foreach (int index, face.vertexIndices)
    {
      Vector3 vertex(vertexGroup->vertices[index-1].X, vertexGroup->vertices[index-1].Y, vertexGroup->vertices[index-1].Z);
      rawVertices.push_back(vertex.X);
      rawVertices.push_back(vertex.Y);
      rawVertices.push_back(vertex.Z);
    }
  }
  static int totalVertices = 0;
  totalVertices += rawVertices.size();
  cout << "Vertices for " << name << ':' << rawVertices.size() << endl;
  cout << "total vertices to date: " << totalVertices << endl;
}
