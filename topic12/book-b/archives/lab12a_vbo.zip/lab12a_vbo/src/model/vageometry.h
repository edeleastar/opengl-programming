#pragma once
#include "geometry.h"

struct VaGeometry : public Geometry
{
  std::vector<float> rawVertices;

  VaGeometry();
  VaGeometry(std::string name, std::istream&, VertexGroup*);

  void render();
  void extractVertices();
};
