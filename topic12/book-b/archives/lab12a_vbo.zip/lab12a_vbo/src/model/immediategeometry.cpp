#include "immediategeometry.h"
using namespace std;

ImmediateGeometry::ImmediateGeometry()
{
}

ImmediateGeometry::ImmediateGeometry(string groupName, istream& is, VertexGroup*group)
: Geometry (groupName, is, group)
{
}

void ImmediateGeometry::render()
{
  foreach (Face &face, faces)
  {
    face.render(vertices);
  }
}

void ImmediateGeometry::extractVertices()
{
  int newIndex=0;
  foreach (Face &face, faces)
  {
    vector<int> groupIndices = face.vertexIndices;
    face.vertexIndices.clear();
    foreach (int index, groupIndices)
    {
      Vector3 vertex(vertexGroup->vertices[index-1].X, vertexGroup->vertices[index-1].Y, vertexGroup->vertices[index-1].Z);
      vertices.push_back(vertex);
      face.vertexIndices.push_back(newIndex);
      newIndex++;
    }
  }
  static int totalVertices = 0;
  totalVertices += vertices.size();
  cout << "Vertices for " << name << ':' << vertices.size() << endl;
  cout << "total vertices to date: " << totalVertices << endl;
}
