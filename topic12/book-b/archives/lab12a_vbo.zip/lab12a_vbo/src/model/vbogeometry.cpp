#include "VboGeometry.h"
using namespace std;

VboGeometry::VboGeometry()
{
}

VboGeometry::VboGeometry(string groupName, istream& is, VertexGroup*group)
: ElementGeometry (groupName, is, group)
{
}

void VboGeometry::render()
{
  glBindBuffer(GL_ARRAY_BUFFER, ids[0]);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ids[1]);

  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FLOAT, 0, 0);
  glDrawElements(GL_TRIANGLES, elements.indices.size(), GL_UNSIGNED_SHORT, 0);
  glDisableClientState(GL_VERTEX_ARRAY);

  glBindBuffer(GL_ARRAY_BUFFER, 0);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
}

void VboGeometry::extractVertices()
{
  ElementGeometry::extractVertices();

  glGenBuffers(2, ids);

  glBindBuffer(GL_ARRAY_BUFFER, ids[0]);
  glBufferData(GL_ARRAY_BUFFER, elements.vertices.size()*sizeof(float), &elements.vertices[0], GL_STATIC_DRAW);

  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ids[1]);
  glBufferData(GL_ELEMENT_ARRAY_BUFFER, elements.indices.size()*sizeof(GLushort), &elements.indices[0], GL_STATIC_DRAW);
}

