#include "lightingmodel.h"

float  ambientLightModerate[] = { 0.3f, 0.3f, 0.3f, 1.0f };
float  diffuseLightModerate[] = { 0.7f, 0.7f, 0.7f, 1.0f };

LightingModel::LightingModel()
: ambientLight(AmbientLight::fullLight)
{
  SpotLight spotLight0 ((GLenum)GL_LIGHT0, Vector3(-50, 50, 0));

  LightSetting setting1 = {ambientLightModerate, GL_AMBIENT};
  LightSetting setting2 = {diffuseLightModerate, GL_DIFFUSE};

  spotLight0.augment(setting1);
  spotLight0.augment(setting2);

  spotLights.insert(spotLight0);
}


void LightingModel::switchOnLights()
{
  ambientLight.switchOn();
  foreach (SpotLight spotLight, spotLights)
  {
    spotLight.switchOn();
  }
  glEnable(GL_NORMALIZE);
}

void LightingModel::positionLights()
{
  foreach (SpotLight spotLight, spotLights)
  {
    spotLight.reposition();
  }
}
