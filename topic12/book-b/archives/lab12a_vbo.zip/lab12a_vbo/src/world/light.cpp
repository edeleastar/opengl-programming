#include "light.h"

float settingTable[][4] =
{
  { 1.0f, 1.0f, 1.0f, 1.0f }, // full
  { 0.5f, 0.5f, 0.5f, 1.0f }, // half
  { 0.2f, 0.2f, 0.2f, 1.0f }  // default
};

AmbientLight::AmbientLight(AmbientLightSetting setting)
: setting(setting)
{
}

void AmbientLight::switchOn()
{
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, settingTable[setting]);
}

SpotLight::SpotLight (GLenum id, Vector3 p)
: id(id), position(p)
{
}

void SpotLight::augment(LightSetting &setting)
{
  lightSettings.insert(setting);
}

void SpotLight::switchOn()
{
  foreach (LightSetting setting, lightSettings)
  {
    glLightfv(id, setting.type, setting.components);
  }
  glEnable(id);
}

void SpotLight::reposition()
{
  float pos[4];
  pos[0] = position.X;
  pos[1] = position.Y;
  pos[2] = position.Z;
  pos[3] = 1;

  glLightfv(id, GL_POSITION, pos);
}
