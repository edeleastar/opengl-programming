#pragma once
#include "actor.h"

struct Grid: public Actor
{
  Grid()
  {}

  void render()
  {
    const float RANGE = 15.0f;
    glLineWidth(2);
    glColor3f(0.0,1.0,0.0);
    glBegin(GL_LINES);
    for(int i=-10; i<=10; ++i)
    {
      float offset = 0.2*float(i)*RANGE;
      glVertex3f(-RANGE, 0, offset);
      glVertex3f( RANGE, 0, offset);
      glVertex3f( offset, 0,-RANGE);
      glVertex3f( offset, 0, RANGE);
    }
    glEnd();
    glLineWidth(1);
  }

};
