#pragma once
#include "libs.h"

enum MaterialTypes {flatRed, flatYellow, flatBlue, flatGreen, flatGray, plasticRed, shinyWhite, brass, bronze,
  chrome, copper, gold, pewter, silver, polishSilver, plasticBlack} ;

void applyMaterial(MaterialTypes material);
