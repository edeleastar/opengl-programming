#include "world.h"
#include "color.h"
#include "light.h"
#include "glutadapter.h"
#include <ctime>

using namespace std;

World* World::s_World = NULL;

World& World::GetInstance()
{
  if (s_World == NULL)
  {
    s_World = new World();
  }
  return *s_World;
}

void World::render()
{
  Color::Blue.renderClear();
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  if (projectors.isPerspective())
  {
    glLoadIdentity();
    cameras.currentCamera->render();
  }
  lightingModel.positionLights();

  scene->render();

  glutSwapBuffers();
}

void World::tickAndRender()
{
  static clock_t lastTime = 0;

  if (lastTime == 0)
    lastTime = clock();

  clock_t currTime = clock();
  clock_t deltaTime = currTime - lastTime;
  float secondsDelta = (float)deltaTime/CLOCKS_PER_SEC;

  scene->tick(secondsDelta);

  glutPostRedisplay();
}

void World::keyPress(unsigned char ch)
{
  if (ch >= '1' && ch <= '4')
  {
    projectors.keyPress(ch);
  }
  else if (ch >= '5' && ch <= '6')
  {
    cameras.keyPress(ch);
  }
  else
  {
    cameras.currentCamera->keyStroke(ch);
  }
  glutPostRedisplay();
}

void World::specialKeyPress(int key, int x, int y)
{
  if (projectors.isPerspective())
  {
    cameras.currentCamera->specialKeyboard(key, x, y);
  }
  glutPostRedisplay();
}

void World::mouseMovement(int x, int y)
{
  cameras.currentCamera->mouseMovement(x,y);
}

void World::initialize(string name, int width, int height)
{
  int argc=0;
  char** argv;
  glutInit(&argc, argv);

  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(width, height);
  glutCreateWindow(name.c_str());

  Color::Black.renderClear();
  glEnable(GL_DEPTH_TEST);
  glFrontFace(GL_CCW);
  glPolygonMode(GL_FRONT,GL_LINE);
  glPolygonMode(GL_BACK,GL_LINE);

  glutKeyboardFunc(keyboard);
  glutReshapeFunc(reshape);
  glutDisplayFunc(renderScene);
  glutSpecialFunc(keyboardSpecial);
  glutPassiveMotionFunc(::mouseMovement);

  glEnable(GL_LIGHTING);
  lightingModel.switchOnLights();
}

void World::start()
{
  timerFunc(0);
  glutMainLoop();
}

