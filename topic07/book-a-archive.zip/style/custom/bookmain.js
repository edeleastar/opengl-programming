$(document).ready(function()
{  
  $(".moodle-book pre").css('background-image', 'url(http://edeleastar.github.io/assets/style/highlight/school_book.png)');
});