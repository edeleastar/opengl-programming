#pragma once
#include <iostream>
#include <vector>
#include "vector3.h"

struct Face
{
  int vertices[3];
  int textures[3];

  Face(std::istream& is);
  void render(std::vector <Vector3>&);
};
