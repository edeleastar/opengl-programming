#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "vector3.h"
#include "face.h"

struct ModelObject
{
  std::string name;
  std::vector<Face> faces;
  std::vector <Vector3> vertices;

  ModelObject();
  ModelObject(std::istream&);
  void render(std::vector <Vector3>&);
};
