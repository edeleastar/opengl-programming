
$(document).ready(function()
{  
  $(".moodle-book pre").css('background-image', 'url(./style/highlight/school_book.png)');
  $('.tab-menu.menu .item').tab();
});
