#pragma once
#include <iostream>
#include <map>
#include <string>
#include <vector>
#include "vector3.h"
#include "mesh.h"
#include "vertexgroup.h"

typedef std::map <std::string, Mesh>  MeshMap;
typedef MeshMap::iterator MeshMapIterator;

struct Model
{
  MeshMap     entities;
  VertexGroup defaultGroup;

  Model();
  bool load(std::istream &is);
  void render();
};
