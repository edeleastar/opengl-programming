#pragma once

#include <iostream>
#include <vector>
#include "vector3.h"

struct VertexGroup
{
  std::vector <Vector3> vertices;

  VertexGroup();
  void load(std::istream&);
};
