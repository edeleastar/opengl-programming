#include "libopengl.h"
#include "mesh.h"
using namespace std;

Mesh::Mesh()
{}

Mesh::Mesh(string groupName, istream& is)
: name(groupName)
{
  string indicator;
  bool stillGroup=true;
  do
  {
    is >> indicator;
    if (indicator == "f")
    {
      faces.push_back(Face(is));
    }
    else if (indicator == "g")
    {
      stillGroup = false;
    }
    else
    {
      string buf;
      getline(is, buf);
    }
  } while (stillGroup && !is.eof());
  is.putback(indicator[0]);
}

void Mesh::render(vector <Vector3>&defaultTable)
{
  cout << " rendering " << name << " with " << faces.size() << "faces" << endl;
  for (unsigned int i = 0; i < faces.size(); i++)
  {
    faces[i].render(defaultTable);
  }
}
