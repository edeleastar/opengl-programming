#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "vector3.h"
#include "face.h"

struct Mesh
{
  std::string name;
  std::vector<Face> faces;

  Mesh();
  Mesh(std::string name, std::istream&);
  void render(std::vector <Vector3>&);
};
