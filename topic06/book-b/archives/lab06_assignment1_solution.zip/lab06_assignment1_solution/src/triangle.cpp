#include "libopengl.h"
#include "triangle.h"
#include "utils.h"
using namespace std;

using namespace std;
Triangle::Triangle(istream &is)
: Geometry(is), p1(is),p2(is),p3(is)
{
}

void Triangle::render()
{
  glBegin( GL_TRIANGLES);
    p1.render();
    p2.render();
    p3.render();
  glEnd();
}
