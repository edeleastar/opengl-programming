#include "utils.h"
using namespace std;

void skipComment(istream &is)
{
  char ch;
  is >> ch;
  if (ch == '#')
  {
    do
    {
      string buf;
      getline(is, buf);
      is >> ch;
    } while (ch == '#');
  }
  is.putback(ch);
}
