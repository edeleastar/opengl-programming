#pragma once
#include <istream>

#define GL_PI 3.1415

void skipComment(std::istream &is);
