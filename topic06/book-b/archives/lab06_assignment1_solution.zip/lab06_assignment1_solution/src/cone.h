#pragma once
#include "geometry.h"

struct Cone : public Geometry
{
  Vector3 origin;
  float radius;
  void drawTriangleFan(Vector3 v, float radius);

  Cone(std::istream&);
  void render();
};
