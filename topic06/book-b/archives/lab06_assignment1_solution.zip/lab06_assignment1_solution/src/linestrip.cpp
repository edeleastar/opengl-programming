#include "libopengl.h"
#include "linestrip.h"
#include "utils.h"
using namespace std;

LineStrip::LineStrip(istream &is)
: Geometry(is)
{
  int size;
  skipComment(is);
  is >> size;
  for (int i = 0; i < size; i++)
  {
    Vector3 vector3(is);
    vertices.push_back(vector3);
  }
}

void LineStrip::render()
{
  glBegin( GL_LINE_STRIP);
  for (unsigned int i = 0; i < vertices.size(); i++)
  {
    vertices[i].render();
  }
  glEnd();
}
