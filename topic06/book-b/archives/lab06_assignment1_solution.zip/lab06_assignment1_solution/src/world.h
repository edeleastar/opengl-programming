#pragma once
#include <string>
#include <vector>
#include "geometry.h"

#define theWorld World::GetInstance()

struct World
{
  public:
    static World& GetInstance();

    void setCmdlineParams(int*argc, char **argv);
    void initialize(int width, int height, std::string name);
    void start();

    void add(Geometry* renderable);
    void render();
    void keyPress(unsigned char ch);

    void tickAndRender();

    static World* s_World;
    std::vector<Geometry*> renderables;

    int minX, maxX, minY, maxY, minZ, maxZ;
    int   *argc;
    char **argv;
};

