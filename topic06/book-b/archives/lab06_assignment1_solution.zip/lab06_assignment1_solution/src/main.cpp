#include "libopengl.h"
#include "model.h"
#include <fstream>
#include <iostream>
#include "cone.h"
#include "world.h"

using namespace std;

Model *model;

void World::keyPress(unsigned char ch)
{
}

void World::tickAndRender()
{
  Cone *cone1 = (Cone*) model->get("cone1");
  cone1->rotate(2, cone1->origin);

  Cone *cone2 =(Cone*) model->get("cone2");
  cone2->rotate(5, cone2->origin);

  Cone *cone3 = (Cone*)model->get("cone3");
  cone3->rotate(3, cone3->origin);

  Cone *cone4 = (Cone*)model->get("cone4");
  cone4->rotate(2, cone4->origin);

  glutPostRedisplay();
}

Model* loadModel(const char *filename)
{
  fstream modelStream;
  modelStream.open(filename, ios::in);
  if (!modelStream.fail())
  {
    model = new Model(modelStream);
  }
  return model;
}

int main(int argc, char* argv[])
{
  theWorld.setCmdlineParams(&argc, argv);
  theWorld.initialize(800,800, "First World");

  Model *model = loadModel("model.txt");
  if (model)
  {
    theWorld.add(model);
  }

  theWorld.start();
  return 0;
}
