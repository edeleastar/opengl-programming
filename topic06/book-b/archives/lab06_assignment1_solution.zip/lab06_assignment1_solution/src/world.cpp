#include "world.h"
#include "libopengl.h"
#include "color.h"
#include "vector3.h"

World* World::s_World = NULL;

void reshape(int w, int h)
{
  glViewport(0, 0, 800,800);
  glMatrixMode ( GL_PROJECTION);

  glLoadIdentity();
  glOrtho(-300,300,-300,300,-300,300);

}

void renderScene(void)
{
  theWorld.render();
}

void keyboard(unsigned char key, int x, int y)
{
  theWorld.keyPress(key);
}

void timerFunc(int value)
{
  theWorld.tickAndRender();
  glutTimerFunc(50, timerFunc, 1);
}

World& World::GetInstance()
{
  if (s_World == NULL)
  {
    s_World = new World();
  }
  return *s_World;
}

void World::setCmdlineParams(int*argc, char **argv)
{
  this->argc = argc;
  this->argv = argv;
}


void World::render()
{
  glMatrixMode( GL_MODELVIEW);

  Color::Black.renderClear();
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  for (unsigned int i=0; i<renderables.size(); i++)
  {
    renderables[i]->render();
  }
  glutSwapBuffers();
}

void World::initialize(int width, int height, std::string name)
{
  glutInit(argc, argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(width, height);
  glutCreateWindow(name.c_str());

  Color::Black.renderClear();
  glEnable(GL_DEPTH_TEST);
  glFrontFace(GL_CCW);
  glPolygonMode(GL_FRONT,GL_LINE);
  glPolygonMode(GL_BACK,GL_LINE);
}

void World::start()
{
  glutKeyboardFunc(keyboard);
  glutReshapeFunc(reshape);
  glutDisplayFunc(renderScene);
  timerFunc(0);
  glutMainLoop();
}

void World::add(Geometry* renderable)
{
  renderables.push_back(renderable);
}



