#pragma once
#include <vector>
#include <map>
#include <istream>
#include <string>
#include "vector3.h"
#include "geometry.h"

typedef std::map <std::string, Geometry*>  GeometryMap;
typedef GeometryMap::iterator GeometryMapIterator;

struct Model : public Geometry
{
  int minX, maxX, minY, maxY, minZ, maxZ;
  GeometryMap entities;

  Geometry* get(std::string name);
  Model(std::istream& is);
  ~Model();
  void render();
};


