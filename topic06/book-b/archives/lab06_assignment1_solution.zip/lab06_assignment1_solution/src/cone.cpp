#include "libopengl.h"
#include "cone.h"
#include "utils.h"
#include <math.h>
using namespace std;

Cone::Cone(istream &is)
: Geometry(is), origin(is)
{
  skipComment(is);
  is >> radius;
}

void Cone::drawTriangleFan(Vector3 centre, float radius)
{
  glBegin(GL_TRIANGLE_FAN);
    centre.render();
    float angle;
    for(angle = 0.0f; angle < (2.0f*GL_PI); angle += (GL_PI/8.0f))
    {
      float x = centre.X+radius*sin(angle);
      float y = centre.Y+radius*cos(angle);
      glVertex2f(x, y);
    }
  glEnd();
}

void Cone::render()
{
  glPushMatrix();
    glRotatef(angle, rotationAxis.X, rotationAxis.Y, rotationAxis.Z);
    glFrontFace(GL_CW);
    drawTriangleFan(origin, radius);
    glFrontFace(GL_CCW);
    drawTriangleFan(Vector3(origin.X, origin.Y, 0), radius);
  glPopMatrix();
}
