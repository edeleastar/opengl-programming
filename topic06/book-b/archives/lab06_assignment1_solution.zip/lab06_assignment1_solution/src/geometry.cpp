#include "geometry.h"
#include <istream>
using namespace std;
#include "utils.h"

Geometry::Geometry(istream &is)
{
  skipComment(is);
  is >> name;
  angle = 0;
}

void Geometry::rotate(int increment, const Vector3& axis)
{
  angle = (angle + increment) % 360;
  rotationAxis = axis;
}
