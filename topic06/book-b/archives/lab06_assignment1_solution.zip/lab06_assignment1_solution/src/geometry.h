#pragma once
#include "vector3.h"
#include <istream>

struct Geometry
{
  Geometry(std::istream& is);
  void rotate(int increment, const Vector3& axis);
  virtual void render()=0;

  std::string name;
  int angle;
  Vector3 rotationAxis;
};
