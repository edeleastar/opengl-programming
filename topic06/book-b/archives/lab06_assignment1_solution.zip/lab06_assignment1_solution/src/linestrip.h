#pragma once
#include "geometry.h"
#include <vector>

struct LineStrip : public Geometry
{
  std::vector<Vector3> vertices;

  LineStrip(std::istream& is);
  void render();
};

