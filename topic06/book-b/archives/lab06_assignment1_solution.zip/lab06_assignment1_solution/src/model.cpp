#include "model.h"
#include "libopengl.h"
#include "geometry.h"
#include "linestrip.h"
#include "triangle.h"
#include "cone.h"
#include "utils.h"
#include <fstream>
#include <vector>
using namespace std;

enum EntityType {LineStripId, TriangleId, ConeId};

Model::Model(istream &is)
: Geometry(is)
{
  int size;
  skipComment(is);
  is >> minX >> maxX >> minY >> maxY >> minZ >> maxZ;
  skipComment(is);
  is >> size;
  for (int i = 0; i < size; i++)
  {
    int typeId;
    skipComment(is);
    is >> typeId;
    Geometry *entity=0;
    switch (typeId)
    {
      case LineStripId: {
                          entity = new LineStrip(is);
                          break;
                        }
      case TriangleId:  {
                          entity = new Triangle(is);
                          break;
                        }
      case ConeId:      {
                          entity = new Cone(is);
                          break;
                        }
    }
    if (entity != 0)
    {
        entities[entity->name] = entity;
    }
  }
}

Geometry* Model::get(string name)
{
  if (entities.find(name) != entities.end())
  {
    return entities.find(name)->second;
  }
  return 0;
}

Model::~Model()
{
  for (GeometryMapIterator iter = entities.begin(); iter != entities.end(); iter++)
   {
    delete iter->second;
   }
}

void Model::render()
{
  for (GeometryMapIterator iter = entities.begin(); iter != entities.end(); iter++)
   {
    iter->second->render();
   }
}
