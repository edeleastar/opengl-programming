#pragma once
#include "geometry.h"

struct Triangle : public Geometry
{
  Vector3 p1, p2, p3;

  Triangle(std::istream& is);
  void render();
};
