#pragma once
#include "color.h"

struct Triangle : public Actor
{
  Vector3 p1, p2, p3;
  Color  c1, c2, c3;

  Triangle(Vector3 p1, Vector3 p2, Vector3 p3,
          Color    c1, Color   c2, Color   c3)
  : p1(p1), p2(p2), p3(p3),
    c1(c1), c2(c2), c3(c3)
  {}

  void render()
  {
    glShadeModel( GL_SMOOTH);
    glPolygonMode(GL_FRONT,GL_FILL);
    glPolygonMode(GL_BACK,GL_FILL);

    glBegin( GL_TRIANGLES);
      c1.render();
      p1.render();
      c2.render();
      p2.render();
      c3.render();
      p3.render();
    glEnd();

    glPolygonMode(GL_FRONT,GL_LINE);
    glPolygonMode(GL_BACK,GL_LINE);
    Color::White.render();
  }
};
