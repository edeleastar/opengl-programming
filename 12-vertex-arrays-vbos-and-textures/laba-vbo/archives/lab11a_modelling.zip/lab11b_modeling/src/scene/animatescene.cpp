#include "animatescene.h"
#include "sphereactor.h"

using namespace std;

AnimateScene :: AnimateScene()
{
}

Actor* AnimateScene::loadActor(GeometryMap::value_type &value)
{
  Actor *actor = 0;
  if (value.first == "pSphere1")
  {
    PhysicsActor * sphere = new SphereActor(&value.second);
    actor = dynamic_cast<Actor*> (sphere);
    // create an anchor
    Vector3 anchor = sphere->position + Vector3(0,5,0);
    // create force generator
    AnchoredSpringForceGenerator * fg =
    new AnchoredSpringForceGenerator(anchor, 1.0, 3.0);
    // add actor<->forceGenerator pair to registry
    forceGeneratorRegistry.add(sphere, fg);
  }
  else if (value.first == "pSphere2" || value.first == "pSphere3")
  {
    actor = new SphereActor(&value.second);
  }
  else
  {
    return Scene::loadActor(value);
  }
  if (actor)
  {
    animateActors[value.first] = (AnimateActor*) actor;
  }
  return actor;
}

void AnimateScene::tick(float secondsDelta)
{
  forceGeneratorRegistry.applyForce(secondsDelta);

  foreach (AnimateActorMap::value_type value, animateActors)
  {
    value.second->integrate(secondsDelta);
  }
}
