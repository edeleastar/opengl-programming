#pragma once
#include "libs.h"
#include "model.h"
#include "actor.h"

struct Scene
{
  Scene();
  void loadActors(Model*);

  virtual Actor* loadActor(GeometryMap::value_type &value);
  virtual void render();
  virtual void tick(float secondsDelta) {}

  ActorMap         actors;
};
