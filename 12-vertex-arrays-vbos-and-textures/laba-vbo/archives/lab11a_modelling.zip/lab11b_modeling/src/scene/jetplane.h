#pragma once
#include "actor.h"

struct JetPlane : public  Actor
{
  JetPlane();
  void render();
};
