#pragma once
#include "libs.h"
#include "vector3.h"

struct LightSetting
{
  float*  components;
  int     type;
};

struct lttype
{
  bool operator() (const LightSetting& s1, const LightSetting& s2) const
  {
    return (s1.type < s2.type);
  }
};

struct AmbientLight
{
  enum AmbientLightSetting {fullLight, halfLight, defaultLight};

  AmbientLight(AmbientLightSetting setting);
  void switchOn();

  AmbientLightSetting setting;
};

struct SpotLight
{
  SpotLight (GLenum id, Vector3 p);
  void augment(LightSetting &setting);

  void switchOn();
  void reposition();

  GLenum  id;
  Vector3 position;
  std::set<LightSetting, lttype> lightSettings;
};

struct ltspotlight
{
  bool operator() (const SpotLight& s1, const SpotLight& s2) const
  {
    return (s1.id < s2.id);
  }
};
typedef std::set<SpotLight, ltspotlight> SpotLightSet;
