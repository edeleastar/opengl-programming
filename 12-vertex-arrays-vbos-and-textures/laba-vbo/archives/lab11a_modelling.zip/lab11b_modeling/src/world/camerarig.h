#pragma once
#include "camera.h"

struct CameraRig
{
  CameraRig();

  void keyPress(unsigned char key);
  void addCamera(std::string str, Camera *camera);

  CameraMap  theCameras;
  Camera    *currentCamera;
};
