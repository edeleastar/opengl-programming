#pragma once
#include "libs.h"
#include "light.h"

struct LightingModel
{
  LightingModel();
  void switchOnLights();
  void positionLights();

  SpotLightSet spotLights;
  AmbientLight ambientLight;
};
