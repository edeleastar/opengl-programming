$(document).ready(function()
{  
  $(".clarity-book pre").css('background-image', 'url(http://edel020.bitbucket.org/assets/highlight/school_book.png)');
});