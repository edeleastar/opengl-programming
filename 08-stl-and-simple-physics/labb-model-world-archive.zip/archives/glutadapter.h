#pragma once

void reshape(int w, int h);
void renderScene(void);
void keyboard(unsigned char key, int x, int y);
void timerFunc(int value);
